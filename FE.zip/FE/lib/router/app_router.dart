// 위치: lib/router/app_router.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

// 모든 화면 파일 임포트
import '../screen/main_screen.dart';
import '../screen/home_screen.dart';
import '../screen/movie_list_screen.dart';
import '../screen/movie_detail_screen.dart';
import '../screen/my_page_screen.dart';

class AppRouter {
  AppRouter._();

  static final router = GoRouter(
    initialLocation: '/home', // 앱 실행 시 처음 보여줄 탭 (홈)
    routes: [
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) {
          return MainScreen(navigationShell: navigationShell);
        },
        branches: [
          // 1번째 탭: 홈 화면
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/home',
                builder: (context, state) => const HomeScreen(),
              ),
            ],
          ),
          
          // 2번째 탭: 영화 목록 화면 + 상세 화면 (Path Parameter 활용)
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/movies',
                builder: (context, state) => const MovieListScreen(),
                routes: [
                  // 영화 카드를 누르면 이동하는 상세 화면 (/movies/1, /movies/2 등)
                  GoRoute(
                    path: ':movieId',
                    builder: (context, state) {
                      final movieId = state.pathParameters['movieId']!;
                      return MovieDetailScreen(movieId: movieId);
                    },
                  ),
                ],
              ),
            ],
          ),
          
          // 3번째 탭: 마이페이지 화면
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/my',
                builder: (context, state) => const MyPageScreen(),
              ),
            ],
          ),
        ],
      ),
    ],
  );
}