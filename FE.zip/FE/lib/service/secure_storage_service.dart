import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageService {
  const SecureStorageService();

  // 인스턴스를 하나만 생성하여 재사용합니다.
  static const _storage = FlutterSecureStorage();
  static const _accessTokenKey = 'access_token';

  Future<void> saveToken(String token) async {
    await _storage.write(
      key: _accessTokenKey,
      value: token,
    );
  }

  Future<String?> readToken() async {
    return await _storage.read(
      key: _accessTokenKey,
    );
  }

  Future<void> clearToken() async {
    await _storage.delete(
      key: _accessTokenKey,
    );
  }
}